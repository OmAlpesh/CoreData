//
//  ViewController.swift
//  CoreDataDemo
//
//  Created by alpesh patel on 1/10/17.
//  Copyright © 2017 alpesh patel. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var address: UITextField!
    @IBOutlet weak var phone: UITextField!
    @IBOutlet weak var status: UILabel!
    
    let managedObjectContext = (UIApplication.shared.delegate
        as! AppDelegate).persistentContainer.viewContext

    
    //MARK:- View cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    //MARK:- Action method
    @IBAction func saveData(_ sender: AnyObject) {
        
        let entityDescription =
            NSEntityDescription.entity(forEntityName: "Contacts",
                                       in: managedObjectContext)
        
        let contact = Contacts(entity: entityDescription!,
                               insertInto: managedObjectContext)
        
        contact.name = name.text!
        contact.address = address.text!
        contact.phone = phone.text!
        
//        contact.relationship?.item = "iPhone"
//         contact.relationship?.quantity = "10"
//         contact.relationship?.salesId = "7"
        
        
        do {
            try managedObjectContext.save()
            name.text = ""
            address.text = ""
            phone.text = ""
            status.text = "Contact Saved"
            
        } catch let error {
            status.text = error.localizedDescription
        }
        
    }
    
    @IBAction func findContact(_ sender: AnyObject) {
        
        let entityDescription =
            NSEntityDescription.entity(forEntityName: "Contacts",
                                       in: managedObjectContext)
        
        let request: NSFetchRequest<Contacts> = Contacts.fetchRequest()
        request.entity = entityDescription
        
        let pred = NSPredicate(format: "(name = %@)", name.text!)
        request.predicate = pred
        
        do {
            var results =
                try managedObjectContext.fetch(request as!
                    NSFetchRequest<NSFetchRequestResult>)
            
            if results.count > 0 {
                let match = results[0] as! NSManagedObject
                
                print(results)
                
                name.text = match.value(forKey: "name") as? String
                address.text = match.value(forKey: "address") as? String
                phone.text = match.value(forKey: "phone") as? String
                status.text = "Matches found: \(results.count)"
                
                
            } else {
                status.text = "No Match"
            }
            
        } catch let error {
            status.text = error.localizedDescription
        }
     
    }

}

