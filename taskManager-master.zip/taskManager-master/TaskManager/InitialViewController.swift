//
//  InitialViewController.swift
//  TaskManager
//
//  Created by Michal Sverak on 10/7/16.
//  Copyright © 2016 MichalSverak. All rights reserved.
//

import UIKit

class InitialViewController: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
