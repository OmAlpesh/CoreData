//
//  SignupVC.swift
//  SpotMyDifference
//
//  Created by ithelp on 03/05/17.
//  Copyright © 2017 Credencys Solution Inc. All rights reserved.
//

import UIKit
import ActiveLabel
import LKAlertController
import IQKeyboardManagerSwift
import BSKeyboardControls

class SignupVC: UIViewController {
    
    // MARK: Var
    var sharedObj: SharedClass?
    lazy var imagePicker = HImagePickerUtils()
    var keyboardControls: BSKeyboardControls?
    
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    
    @IBOutlet weak var btnCameraImage: UIButton!
    
    @IBOutlet weak var txtUsername: FloatLabelTextField!
    
    @IBOutlet weak var txtEmail: FloatLabelTextField!
    
    @IBOutlet weak var txtPassword: FloatLabelTextField!
    
    @IBOutlet weak var txtPasswordConfirm: FloatLabelTextField!
    
    @IBOutlet weak var lblTocPP: ActiveLabel!
    
    @IBOutlet weak var imgImageView: UIImageView!
    
    // MARK: ViewController Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
        setupUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func setupUI() {
        
        //Shared Object
        sharedObj = SharedClass.sharedInstance
        
        //SetupLable
        //setupLable()
        
        //Setup Textfield
        let fields = [txtUsername, txtEmail, txtPassword, txtPasswordConfirm]
        keyboardControls = BSKeyboardControls.init(fields: (fields as? [UITextField])!)
        keyboardControls?.delegate = self
    }
    
    /*func setupLable() {
        let customTypeTOU = ActiveType.custom(pattern: "Terms of Use")
        let customTypePP = ActiveType.custom(pattern: "Privacy Policy.")
        
        lblTocPP.enabledTypes = [customTypeTOU, customTypePP]
        lblTocPP.customSelectedColor[customTypeTOU] = UIColor.darkGray
        lblTocPP.customSelectedColor[customTypePP] = UIColor.lightGray
        
        //lblTocPP.customColor[customTypeTOU] = UIColor(red: 255/255.0, green: 255/255.0, blue: 0/255.0, alpha: 1)
        
        lblTocPP.text = "By clicking Register, you have read and agree to the Terms of Use and Privacy Policy."
        
        weak var weakSelf = self
        
        self.lblTocPP.handleCustomTap(for: customTypePP) { _ in
            
            if let SignupVC = ConstantClass.Storyboard.login.instantiateViewController(withIdentifier: "TermsOfUseVC") as? PrivacyPolicyVC {
                weakSelf?.navigationController?.pushViewController(SignupVC)
            }
        }
        
        self.lblTocPP.handleCustomTap(for: customTypeTOU) { _ in
            
            if let SignupVC = ConstantClass.Storyboard.login.instantiateViewController(withIdentifier: "TermsOfUseVC") as? PrivacyPolicyVC {
                weakSelf?.navigationController?.pushViewController(SignupVC)
            }
        }
    }*/
    
    func chooseImageFromCamera() {
        
        imagePicker.takePhoto(presentFrom: self, completion: { [unowned self] (image, status) in
            if status == .success {
                self.imgImageView.image = image
            } else {
                if status == .denied {
                    HImagePickerUtils.showTips(at: self, type: .takePhoto)
                } else {
                    print(status.description())
                    //Alert(message: status.description()).showOK()
                }
            }
        })
    }
    
    func chooseImageFromGallary() {
        
        imagePicker.choosePhoto(presentFrom: self.navigationController!, completion: { [unowned self] (image, status) in
            if status == .success {
                self.imgImageView.image = image
            } else {
                if status == .denied {
                    HImagePickerUtils.showTips(at: self, type: .choosePhoto)
                } else {
                    print(status.description())
                }
            }
        })
    }
    
    // MARK: Actions
    @IBAction func chooseImageAction(_ sender: UIButton) {
        self.view.endEditing(true)
        ActionSheet(title: nil, message: "Choose option")
            .addAction("Cancel")
            .addAction("Camera", style: .destructive, handler: { _ in
                self.chooseImageFromCamera()
            }).addAction("Gallery", style: .destructive, handler: { _ in
                self.chooseImageFromGallary()
            }).show()
    }
    
    @IBAction func registerAction(_ sender: UIButton) {
        self.view.endEditing(true)
        proceedSignUp()
    }
    
    // MARK: Other
    deinit {
        print("deinit-->" + String(describing: type(of: self)))
    }
    
    /// Proceed For Login
    func proceedSignUp() {
        
      //  let dictRegistration = ["userName": txtUsername.text!, "emailId": txtEmail.text! , "password": txtPassword.text!, "confirmPassword": txtPasswordConfirm.text!] as [String : Any]
     
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        let registration = Registration(context: context)
        registration.userName = txtUsername.text!
        registration.emailId = txtEmail.text!
        registration.password = txtPassword.text!
        registration.confirmPassword = txtPasswordConfirm.text!
        // Save the data to coredata
        
        (UIApplication.shared.delegate as! AppDelegate).saveContext()
        let _ = navigationController?.popViewController(animated: true)
        
    }
}

extension SignupVC : BSKeyboardControlsDelegate {
    func keyboardControlsDonePressed(_ keyboardControls: BSKeyboardControls) {
        self.view.endEditing(true)
    }
    
    func keyboardControls(_ keyboardControls: BSKeyboardControls, selectedField field: UIView, in direction: BSKeyboardControlsDirection) {
        
    }
}

extension SignupVC : UITextFieldDelegate {
    func textFieldDidBeginEditing(_ textField: UITextField) {
        keyboardControls?.activeField = textField
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        return true
    }
}
