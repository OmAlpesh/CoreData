//
//  ViewController.swift
//  SpotMyDifference
//
//  Created by Tejas on 4/30/17.
//  Copyright © 2017 Credencys Solution Inc. All rights reserved.
//

import UIKit
import LKAlertController
import IQKeyboardManagerSwift
import BSKeyboardControls

class LoginVC: UIViewController {
    
    // MARK: Var
    @IBOutlet weak var txtEmail: FloatLabelTextField!
    @IBOutlet weak var txtPassword: FloatLabelTextField!
    var sharedObj: SharedClass?
    var keyboardControls: BSKeyboardControls?
    
    lazy var arrRegistration: [Registration] = []
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    // MARK: ViewController Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        setupUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(animated)
    }
    
    func setupUI() {
        
        //Shared Object
        sharedObj = SharedClass.sharedInstance
        
        //Setup Textfield
        let fields = [txtEmail, txtPassword]
        keyboardControls = BSKeyboardControls.init(fields: (fields as? [UITextField])!)
        keyboardControls?.delegate = self
        
    }
    
    // MARK: Actions
    @IBAction func forgotPasswordTapped(_ sender: UIButton) {
        gotoForgotPasswordVC()
    }
    
    @IBAction func loginTapped(_ sender: UIButton) {
        //proceedLogin()
        getUserData()
    }
    
    @IBAction func signupTapped(_ sender: UIButton) {
        
        if let SignupVC = ConstantClass.Storyboard.login.instantiateViewController(withIdentifier: "SignupVC") as? SignupVC {
            
            NavigationMethodClass.navigateTo(SignupVC, inNavigationViewController: self.navigationController!, animated: true)
        }
    }
    
    // MARK: Other
    deinit {
        print("deinit-->" + String(describing: type(of: self)))
    }
    
    /// Proceed For Forgot Password
    func gotoForgotPasswordVC () {
        
        if let SignupVC = ConstantClass.Storyboard.login.instantiateViewController(withIdentifier: "ForgotPasswordVC") as? ForgotPasswordVC {
            
            NavigationMethodClass.navigateTo(SignupVC, inNavigationViewController: self.navigationController!, animated: true)
        }
    }
    
    func getUserData() {
        do {
            arrRegistration = try context.fetch(Registration.fetchRequest())
            print(arrRegistration.count)
             print(arrRegistration[0].userName!)
            
            for item in arrRegistration {
                
            if item.emailId == txtEmail.text! && item.password == txtPassword.text! {
                   print("Success")
                 _ = Alert(message: "Login Success").showOkay()
                
                if let view = ConstantClass.Storyboard.login.instantiateViewController(withIdentifier: "ViewController") as? ViewController {
                    
                    NavigationMethodClass.navigateTo(view, inNavigationViewController: self.navigationController!, animated: true)
                }

                    break
            } else {
                    print("Not Match")
                  //_ = Alert(message: "Login Fail").show()
                }
            }
        }
        catch {
            print("Fetching Failed")
        }
    }

    /// Proceed For Login
    func proceedLogin() {
        
        
        
      //  var dict = [String:Any]()
        //    dict = ["emailId": txtEmail.text!, "password": txtPassword.text!]
      
    }
}

extension LoginVC : BSKeyboardControlsDelegate {
    func keyboardControlsDonePressed(_ keyboardControls: BSKeyboardControls) {
        self.view.endEditing(true)
    }
    
    func keyboardControls(_ keyboardControls: BSKeyboardControls, selectedField field: UIView, in direction: BSKeyboardControlsDirection) {
        
    }
}

extension LoginVC : UITextFieldDelegate {
    func textFieldDidBeginEditing(_ textField: UITextField) {
        keyboardControls?.activeField = textField
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        return true
    }
}
