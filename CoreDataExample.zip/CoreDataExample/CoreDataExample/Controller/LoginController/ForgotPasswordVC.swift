//
//  ForgotPasswordVC.swift
//  SpotMyDifference
//
//  Created by ithelp on 05/05/17.
//  Copyright © 2017 Credencys Solution Inc. All rights reserved.
//

import UIKit
import LKAlertController
import IQKeyboardManagerSwift
import BSKeyboardControls

class ForgotPasswordVC: UIViewController {
    
    // MARK: Var
    @IBOutlet weak var txtEmail: FloatLabelTextField!
    var sharedObj: SharedClass?
    var keyboardControls: BSKeyboardControls?
    
    // MARK: ViewController Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Apply Navigation Theme
        setupUI()
        
        //Shared Object
        sharedObj = SharedClass.sharedInstance
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
    }
    
    // MARK: Actions
    @IBAction func forgotPasswordAction(_ sender: Any) {

    }
    
    // MARK: - Other
    deinit {
        print("deinit-->" + String(describing: type(of: self)))
    }
    
    func setupUI() {

        //Shared Object
        sharedObj = SharedClass.sharedInstance
        
        //Setup Textfield
        let fields = [txtEmail]
        keyboardControls = BSKeyboardControls.init(fields: (fields as? [UITextField])!)
        keyboardControls?.delegate = self
    }
}

extension ForgotPasswordVC : BSKeyboardControlsDelegate {
    func keyboardControlsDonePressed(_ keyboardControls: BSKeyboardControls) {
        self.view.endEditing(true)
    }
    
    func keyboardControls(_ keyboardControls: BSKeyboardControls, selectedField field: UIView, in direction: BSKeyboardControlsDirection) {
        
    }
}

extension ForgotPasswordVC : UITextFieldDelegate {
    func textFieldDidBeginEditing(_ textField: UITextField) {
        keyboardControls?.activeField = textField
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        return true
    }
}
