//
//  HImagePickerUtils.swift
//  HSwiftTemp
//
//  Created by JuanFelix on 10/28/15.
//  Copyright © 2015 SKKJ-JuanFelix. All rights reserved.
//

import UIKit
import AVFoundation
import AssetsLibrary
import MobileCoreServices
import Photos

public enum HStatus {
    case success, canceled, cameraDisable, photoLibDisable, notImage
    case notDetermined
    case restricted
    case denied
    case authorized
    
    public func description() -> String {
        switch self {
        case .success:
            return "Success"
        case .canceled:
            return "Cancel selection"
        case .cameraDisable:
            return "The device does not support taking pictures"
        case .photoLibDisable:
            return "The device does not support resource selection"
        case .notImage:
            return "Can not get pictture"
        case .notDetermined:
            return "No authorization is made"
        case .restricted:
            return "Blocked Album/Camera access"
        case .denied:
            return "Album/Camera access denied"
        case .authorized:
            return "Authorized"
        }
    }
}

public enum HChooseType {
    case takePhoto, choosePhoto
    public func description() -> String {
        switch self {
        case .takePhoto:
            return "Camera"
        case .choosePhoto:
            return "Album"
        }
    }
}

public typealias HCompletion = (UIImage?, HStatus) -> Void

/// HImagePickerUtils
public class HImagePickerUtils: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    private var pickPhotoEnd: HCompletion?
    
    public func takePhoto(presentFrom rootVC: UIViewController, completion: HCompletion?) {
        self.pickPhotoEnd = completion
        if HImagePickerUtils.isCameraAvailable() && HImagePickerUtils.doesCameraSupportTakingPhotos() {
            HImagePickerUtils.cameraAuthorized { (authorized, status) in
                if authorized || status == .notDetermined {
                    let controller = UIImagePickerController()
                    controller.view.backgroundColor = UIColor.white
                    controller.sourceType = UIImagePickerControllerSourceType.camera
                    controller.mediaTypes = [kUTTypeImage as String]
                    controller.allowsEditing = false
                    controller.cameraDevice = .front
                    controller.delegate = self
                    
                    if #available(iOS 8.0, *) {
                        controller.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
                    }
                    rootVC.present(controller, animated: true, completion: nil)
                } else {
                    self.pickPhotoEnd?(nil, status)
                }
            }
        } else {
            self.pickPhotoEnd?(nil, HStatus.cameraDisable)
        }
    }
    
    public func choosePhoto(presentFrom rootVC: UIViewController, completion: HCompletion?) {
        self.pickPhotoEnd = completion
        if HImagePickerUtils.isPhotoLibraryAvailable() {
            HImagePickerUtils.photoAuthorized({ (authorized, status) in
                if authorized || status == .notDetermined {
                    let controller = UIImagePickerController()
                    controller.view.backgroundColor = UIColor.white
                    controller.sourceType = UIImagePickerControllerSourceType.photoLibrary
                    var mediaTypes = [String]()
                    if HImagePickerUtils.canUserPickPhotosFromPhotoLibrary() {
                        mediaTypes.append(kUTTypeImage as String)
                    }
                    controller.allowsEditing = false
                    controller.mediaTypes = mediaTypes
                    if #available(iOS 8.0, *) {
                        controller.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
                    }
                    controller.delegate = self
                    rootVC.present(controller, animated: true, completion: nil)
                } else {
                    self.pickPhotoEnd?(nil, status)
                }
            })
        } else {
            self.pickPhotoEnd?(nil, HStatus.photoLibDisable)
        }
    }
    
    // MARK: UIImagePickerControllerDelegate
    public func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let mediaType = info[UIImagePickerControllerMediaType] as? NSString {
            if mediaType.isEqual(to: kUTTypeImage as String) {
                
                var theImage: UIImage!
                if picker.allowsEditing {
                    if let image = info[UIImagePickerControllerEditedImage] as? UIImage {
                        theImage = image
                    }
                } else {
                    
                    if let image = info[UIImagePickerControllerOriginalImage] as? UIImage {
                        theImage = image
                    }
                }
                self.pickPhotoEnd?(theImage, HStatus.success)
            } else {
                self.pickPhotoEnd?(nil, HStatus.notImage)
            }
            picker.dismiss(animated: true, completion: nil)
        }
    }
    
    public func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true) {
            self.pickPhotoEnd?(nil, HStatus.canceled)
        }
    }
    
    // MARK: Whether the user is authorized
    public static func cameraAuthorized(_ completion: ((Bool, HStatus) -> Void)?) {
        let status = AVCaptureDevice.authorizationStatus(forMediaType: AVMediaTypeVideo)
        switch status {
        case .authorized:
            completion?(true, .authorized)
        case .notDetermined:
            completion?(false, .notDetermined)
        case .restricted:
            completion?(false, .restricted)
        case .denied:
            completion?(false, .denied)
        }
    }
    
    public static func photoAuthorized(_ completion: ((Bool, HStatus) -> Void)?) {
        let status = PHPhotoLibrary.authorizationStatus()
        switch status {
        case .authorized:
            completion?(true, .authorized)
        case .notDetermined:
            completion?(false, .notDetermined)
        case .restricted:
            completion?(false, .restricted)
        case .denied:
            completion?(false, .denied)
        }
    }
    
    // MARK: Whether the camera function is available
    public static func isCameraAvailable() -> Bool {
        return UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.camera)
    }
    
    // MARK: Whether the front camera is available
    public static func isFrontCameraAvailable() -> Bool {
        return UIImagePickerController.isCameraDeviceAvailable(UIImagePickerControllerCameraDevice.front)
    }
    
    // MARK: Whether the rear camera is available
    public static func isRearCameraAvailable() -> Bool {
        return UIImagePickerController.isCameraDeviceAvailable(UIImagePickerControllerCameraDevice.rear)
    }
    
    // MARK: To determine whether to support a certain multimedia type: camera, video
    public static func cameraSupportsMedia(paramMediaType: NSString, sourceType: UIImagePickerControllerSourceType) -> Bool {
        var result = false
        if paramMediaType.length == 0 {
            return false
        }
        let availableMediaTypes = NSArray(array: UIImagePickerController.availableMediaTypes(for: sourceType)!)
        availableMediaTypes.enumerateObjects({ (obj: Any, _: Int, stop: UnsafeMutablePointer<ObjCBool>) in
            if let type = obj as? NSString {
            if type.isEqual(to: paramMediaType as String) {
                result = true
                stop[0] = true
            }
            }
        })
        return result
    }
    
    // MARK: Check whether the camera supports video recording
    public static func doesCameraSupportShootingVides() -> Bool {
        return self.cameraSupportsMedia(paramMediaType: kUTTypeMovie, sourceType: UIImagePickerControllerSourceType.camera)
    }
    // MARK: Check whether the camera supports taking pictures
    public static func doesCameraSupportTakingPhotos() -> Bool {
        return self.cameraSupportsMedia(paramMediaType: kUTTypeImage, sourceType: UIImagePickerControllerSourceType.camera)
    }
    
    // MARK: Whether the album is available
    public static func isPhotoLibraryAvailable() -> Bool {
        return UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.photoLibrary)
    }
    
    // MARK: Whether you can select a video in the album
    public static func canUserPickVideosFromPhotoLibrary() -> Bool {
        return self.cameraSupportsMedia(paramMediaType: kUTTypeMovie, sourceType: UIImagePickerControllerSourceType.photoLibrary)
    }
    
    // MARK: Whether you can select an image in the album
    public static func canUserPickPhotosFromPhotoLibrary() -> Bool {
        return self.cameraSupportsMedia(paramMediaType: kUTTypeImage, sourceType: UIImagePickerControllerSourceType.photoLibrary)
    }
    
    public static func showTips(at rootVC: UIViewController!, type: HChooseType) {
        if #available(iOS 8.0, *) {
            let alertVC = UIAlertController(title: nil, message: "You stopped it \(type.description())access permission", preferredStyle: UIAlertControllerStyle.alert)
            let openIt = UIAlertAction(title: "Open Setting", style: UIAlertActionStyle.default, handler: { (_: UIAlertAction) -> Void in
                if let url = URL(string: UIApplicationOpenSettingsURLString) {
                    if #available(iOS 10.0, *) {
                        UIApplication.shared.open(url, options: [:], completionHandler: nil)
                    } else {
                        // Fallback on earlier versions
                        UIApplication.shared.openURL(url)
                    }
                }
                
            })
            alertVC.addAction(openIt)
            rootVC.present(alertVC, animated: true, completion: nil)
        } else {
            let alertVC = UIAlertController(title: "Prompt", message: "Please go to the 'system settings | privacy | \(type.description())' Turn on camera access", preferredStyle: UIAlertControllerStyle.alert)
            rootVC.present(alertVC, animated: true, completion: nil)
        }
    }
}
