//
//  CommonMethods.swift
//  BeingInTouch
//
//  Created by Siddhant jain on 22/08/16.
//  Copyright © 2016 Siddhant jain Credencys. All rights reserved.
//

import UIKit
import MBProgressHUD
import Crashlytics

class NavigationMethodClass: NSObject {
    
    // MARK: Variables
    static var navControl: UINavigationController?
    
    static var hud: MBProgressHUD = MBProgressHUD()
    static func push_POP_to_ViewController(_ destinationVC: UIViewController, nav: UINavigationController, isAnimated: Bool) {
        print(destinationVC)
        print(nav)
        var VCFound: Bool = false
        let viewControllers: NSArray = (nav.viewControllers) as NSArray
        var indexofVC: NSInteger = 0
         print(viewControllers)
        for  vc  in viewControllers {
            
            if (vc as AnyObject).nibName == (destinationVC.nibName) {
                VCFound = true
                break
            } else {
                indexofVC += 1
            }
        }
        if VCFound == true {
            nav.popToViewController((viewControllers.object(at: indexofVC) as? UIViewController)!, animated: isAnimated)
        
        } else {
            nav.pushViewController(destinationVC, animated: isAnimated)
        }
    }
    //
    // MARK: Navigation Methdods
    /**
     This methods manage the navigation.
     
     - parameter destinationVC:        destination view controller
     - parameter navigationController: navigation controller object
     - parameter animated:             Animation (true/false)
     */
    class func navigateTo(_ destinationVC: UIViewController, inNavigationViewController navigationController: UINavigationController, animated: Bool) {
        //Assign to global value
        print(navigationController)
        navControl = navigationController
        
        //alpesh
        navigationController.pushViewController(destinationVC, animated: animated)
       // push_POP_to_ViewController(destinationVC, nav: navControl!, isAnimated: animated)

    }
    /**
     This methods is used to get reference of already present viewcontroller object.
     
     - parameter destinationVC:        destination view controller
     - parameter navigationController: navigation controller object
     
     - returns: Object of destination view controller
     */
    class func findViewControllerRefInStack(_ destinationVC: UIViewController, inNavigationViewController navigationController: UINavigationController) -> UIViewController {
        var VCFound = false
        var viewControllers = navigationController.viewControllers
        var indexofVC = 0
        for vc: UIViewController in viewControllers {
            if vc.nibName == (destinationVC.nibName) {
                VCFound = true
                break
            } else {
                indexofVC += 1
            }
        }
        if VCFound == true {
            return viewControllers[indexofVC]
        } else {
            return destinationVC
        }
    }
    
    /// Setting Up UI of navigation Bar to specific background
    ///
    /// - Parameters:
    ///   - navControl: Object of Navigation Controller
    ///   - backgroundColour: Background Colour
    class func setUpTransperantNavigationBar(_ navControl: UINavigationController, navItem: UINavigationItem, title: String, fontColour: UIColor, backgroundColour: UIColor, shouldShowBackButton isBackButtonShow: Bool) {
        //Back btn
        if isBackButtonShow {
            let barButtonItem: UIBarButtonItem = UIBarButtonItem(image: UIImage(named: "ic_back"), style: .plain, target: self, action: #selector(goBack))
            navItem.leftBarButtonItem = barButtonItem
        }
        navControl.navigationBar.setBackgroundImage(UIImage(color: backgroundColour, size: CGSize(width: 10, height: 10)), for:UIBarMetrics.default)
        navControl.navigationBar.isTranslucent = true
        navControl.navigationBar.isHidden = false
        navControl.navigationBar.shadowImage = UIImage()
        navControl.setNavigationBarHidden(false, animated:true)
    }
    
    //
    /**
     Setting Up UI of navigation Bar
     
     - parameter navControl:  Object of Navigation Controller
     - parameter navItem: Object of Navigation Item
     - parameter title:   Title of Navigation Bar
     */
    class func setUpNavigationBar(_ navControl: UINavigationController,
                                  navItem: UINavigationItem,
                                  title: NSString,
                                  transperant isTrans: Bool,
                                  hidden isHidden: Bool,
                                  navbgColour bgColour: Int,
                                  navFontColour fontColour: Int,
                                  shouldShowBackButton isBackButtonShow: Bool) {
        
        self.navControl = navControl
        
        if  !isHidden {
            navControl.navigationBar.isHidden = false
            
            //Back btn
            if isBackButtonShow {
                let barButtonItem: UIBarButtonItem = UIBarButtonItem(image: UIImage(named: "ic_back"), style: .plain, target: self, action: #selector(goBack))
                navItem.leftBarButtonItem = barButtonItem
            }
            
            if isTrans {
                navControl.navigationBar.isTranslucent = isTrans
                navControl.navigationBar.setBackgroundImage(UIImage(color: UIColor.white, size: CGSize(width: 10, height: 10)), for: .default)
                navControl.navigationBar.shadowImage = UIImage()
            } else {
                navControl.view.backgroundColor = UIColor.init(hex: bgColour)
                navControl.navigationBar.isTranslucent = isTrans
                navControl.navigationBar.barTintColor = UIColor.init(hex: bgColour)
            }
            navItem .title = title as String
            navControl.navigationBar.tintColor = UIColor.white
        } else {
            navControl.navigationBar.isHidden = true
        }
    }
    
    
    static func goBack() {
        DispatchQueue.main.async {
            navControl!.popViewController(animated: true)
        }
    }
    
    class func showAlertWithTextField(title: String, message: String, textFields: [UITextField], shouldBeNil: Bool, viewController: UIViewController) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        let okAction = UIAlertAction(title: "OK", style: .default) { (_) -> Void in
            if !textFields.isEmpty {
                for textField in textFields {
                    if shouldBeNil {
                        DispatchQueue.main.async(execute: {
                            textField.text = ""
                            textField.becomeFirstResponder()
                        })
                    } else {
                        DispatchQueue.main.async(execute: {
                            textField.becomeFirstResponder()
                        })
                    }
                }
            }
            DispatchQueue.main.async(execute: {
                viewController.dismiss(animated: true, completion: { () -> Void in
                })
            })
        }
        alert.addAction(okAction)
        DispatchQueue.main.async(execute: {
            viewController.present(alert, animated: true, completion: nil)
        })
    }
    class func showMBProgressHud(_ nav: UINavigationController) {
        DispatchQueue.main.async(execute: {
            hud = MBProgressHUD.showAdded(to: nav.view, animated: true)
        })
    }
    class func  hideMBProgressHud() {
        DispatchQueue.main.async(execute: {
            hud.hide(animated: true)
        })
    }
    
    class func delay(delay: Double, closure: @escaping () -> Void) {
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
            closure()
        }
    }
    
}
