//
//  AlertMessages.swift
//  BeingInTouch
//
//  Created by Siddhant jain on 22/08/16.
//  Copyright © 2016 Siddhant jain Credencys. All rights reserved.
//

import UIKit

class AlertMessagesClass: NSObject {
    // MARK: Internet Connection Unavailable
    static let strAlertNetworkUnavailable = "You don't have any internet connection right now.Try later!"
    
    // MARK: Internet Connection Unavailable
    static let strWSError = "Something went wrong!"
    
    // MARK: Login ViewController
    static let strAlertUsrNameEmpty = "Please enter username."
    static let strAlertPwdEmpty = "Please enter password."
    static let strAlertPwdShort = "Password should be at least 6 characters long."
    static let strAlertPwdLong = "Password should not be more than 40 characters."
    static let strAlertPwdHasSpace = "Password should not contain space."
    
    // MARK: SignUpViewController
    static let strAlertUserNameEmpty = "Please enter username."
    static let strAlertUserNameContainSpace = "Username should not contain space."
    static let strAlertFirstNameEmpty = "Please enter first name."
    static let strAlertLastNameEmpty = "Please enter last name."
    static let strAlertEmailEmpty = "Please enter Email."
    static let strAlertEmailInvalid = "Please enter valid Email."
    static let strAlertCountryCodeEmpty = "Please select country code."
    static let strAlertPhoneNoEmpty = "Please enter phone number."
    static let strAlertPhoneNoInvalid = "Please enter valid phone number."
    static let strAlertPhoneNoShort = "Phone number should be atleast 8 digits long."
    static let strAlertConfirmPassDoesNotMatch = "Passwords do not match."
    static let strAlertOldPwdEmpty = "Please enter current password."
    static let strAlertNewPwdEmpty = "Please enter new password."
    static let strAlertConfirmPwdEmpty = "Please enter confirm password."
    
    // MARK: CreateGameViewController
    static let strAlertGameImageEmpty = "Please upload the game profile image."
    static let strAlertGameNameEmpty = "Please enter the game name."
    static let strAlertGameDescriptionEmpty = "Please enter the game description."
    static let strAlertGameDescriptionLong = "Description should not be more than 200 words."
    static let strAlertGameDateEmpty = "Please provide the game prize effective date."
    static let strAlertGameImagesEmpty = "Please upload either 5 or 10 images."
    static let strAlertGamePriceOneEmpty = "Please enter the first game prize."
    static let strAlertGamePriceTwoEmpty = "Please enter the second game prize."
    static let strAlertGamePriceOneTwoEmpty = "Please enter price 1 and 2."
    
    static let strAlertGamePriceOneGraterTwo = "The second game prize should be lower than the first game prize."
    static let strAlertGamePriceTwoGraterThree = "The third game prize should be lower than the second game prize."
    
    // MARK: DashboardViewControlller
    static let strAlertGameListEmpty = "No games available."
    static let strAlertSearchEmpty = "No search result found."
    
    // MARK: DashboardVC
    static let strAlertGameSearchEmpty = "No Game found."
    
    // MARK: FollowingFollowers
    static let strAlertUsersEmpty = "No users found."
    
    // MARK: CommentsVC
    static let strAlertCommentEmpty = "Please enter comment."
    
    // MARK: SettingsViewController
    static let strAlertLogout = "Are you sure you want to sign out?"
    static let strAlertLogoutError = "Unable to logout. Please try again."
}
