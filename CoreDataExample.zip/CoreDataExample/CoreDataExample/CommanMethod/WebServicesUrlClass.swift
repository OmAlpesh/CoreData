//
//  WebServiceList.swift
//  BeingInTouch
//
//  Created by Siddhant jain on 22/08/16.
//  Copyright © 2016 Siddhant jain Credencys. All rights reserved.
//

import UIKit

class WebServicesUrlClass: NSObject {
    
    //---Platform----
    struct Platform {
        static let android = "1"
       // static let ios = "2"
        //alpesh
         static let ios = "3"
    }
    
    //--Static Auth-
    static let strAuthHeader = "am1iNGRuWDlMSg=="
    
    struct Header {
        static let header = ["Token": strAuthHeader]
    }
    
    //--Service Version--
    static let strCurrentVersion = "v1"
    
    //Local
    static let strServerPath =  "http://dev.credencys.com/spotthedifference/api/web/index.php/v1/webservices/"
    @IBOutlet weak var lblBy: UILabel!
    //static let strServerPath =  "http://192.168.1.50/spotthedifference/api/web/index.php/v1/webservices/"
    
    //---Login----
    struct Login {
        static let name = "login"
        static var webservice = strServerPath + name
    }
    
    //---Registration----
    struct Registration {
        static let name = "registration"
        static var webservice = strServerPath + name
    }
    
    //---Registration----
    struct ForgetPassword {
        static let name = "forgot-password"
        static var webservice = strServerPath + name
    }
    
    //---ChangePassword----
    struct ChangePassword {
        static let name = "change-password"
        static var webservice = strServerPath + name
    }
    
    //---MyProfile----
    struct MyProfile {
        static let name = "get-my-profile"
        static var webservice = strServerPath + name
    }
    
    //---EditProfile----
    struct EditProfile {
        static let name = "edit-my-profile"
        static var webservice = strServerPath + name
    }
    
    //---CreateGame----
    struct CreateGame {
        static let name = "create-game"
        static var webservice = strServerPath + name
    }
    
    //---Dashboard----
    struct Dashboard {
        static let name = "dashboard"
        static var webservice = strServerPath + name
    }
    
    //---GameDetailsVC----
    struct GameDetailsVC {
        static let name = "views-count"
        static var webservice = strServerPath + name
    }
    
    //---GameDetailsVC----
    struct GameDetailsLike {
        static let name = "likes"
        static var webservice = strServerPath + name
    }
    
    //---LeaderBoardVC----
    struct LeaderBoardVC {
        static let name = "leadership-board"
        static var webservice = strServerPath + name
    }
    
    //---CommentVC----
    struct CommentVC {
        static let name = "comment-listing"
        static var webservice = strServerPath + name
    }
    
    //---CommentAddVC----
    struct CommentAddVC {
        static let name = "comments"
        static var webservice = strServerPath + name
    }
    
    //---CommentRemoveVC----
    struct CommentRemoveVC {
        static let name = "remove-comments"
        static var webservice = strServerPath + name
    }
    
    //---ProfileVCFollowing----
    struct ProfileVCFollowing {
        static let name = "following-list"
        static let webservice = strServerPath + name
    }
    
    //---ProfileVCFollowers----
    struct ProfileVCFollowers {
        static let name = "follower-list"
        static let webservice = strServerPath + name
    }
    
    //---OtherProfileVCFollowing----
    struct OtherProfileVCFollowing {
        static let name = "other-user-following"
        static let webservice = strServerPath + name
    }
    
    //---OtherProfileVCFollowers----
    struct OtherProfileVCFollowers {
        static let name = "other-user-followers"
        static let webservice = strServerPath + name
    }
    
    //---ProfileVCfollow----
    struct ProfileVCfollow {
        static let name = "follow"
        static let webservice = strServerPath + name
    }
    
    //---MyProfileVCUnfollow----
    struct ProfileVCUnfollow {
        static let name = "unfollow"
        static let webservice = strServerPath + name
    }
    
    //---ProfileVCRequestAccRej----
    struct ProfileVCRequestAccRej {
        static let name = "request-accept-reject"
        static let webservice = strServerPath + name
    }
    
    //---SettingsVCAccountType----
    struct SettingsVCAccountType {
        static let name = "account-type"
        static let webservice = strServerPath + name
    }
    
    //---PlayGameVC----
    struct PlayGameVC {
        static let name = "get-gamedetail"
        static let webservice = strServerPath + name
    }
    
    //---PlayGameVCBooster----
    struct PlayGameVCBooster {
        static let name = "store-booster"
        static let webservice = strServerPath + name
    }
    
    //alpesh
    //---PlayGameVCBooster----
    struct PlayGameVCStoreScore {
        static let name = "store-gamescore"
        static let webservice = strServerPath + name
    }

    struct UserLogOut {
        static let name = "logout"
        static let webservice = strServerPath + name
    }
}
