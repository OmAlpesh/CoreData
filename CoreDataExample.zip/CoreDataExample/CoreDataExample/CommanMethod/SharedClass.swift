//
//  Shared.swift
//  GoCity
//
//  Created by Siddhant jain on 05/12/15.
//  Copyright © 2015 Siddhant jain. All rights reserved.
//

import Foundation
import CoreLocation
import ReachabilitySwift
import SwifterSwift
import Kingfisher

class SharedClass: NSObject, CLLocationManagerDelegate {
    
    static let sharedInstance = sharedInstance1
    var reachability: Reachability?
    var isReachable: Bool?
    
    fileprivate override init() {
        
        super.init()
        
        //Reachability
        do {
            reachability = Reachability.init()
        }
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.reachabilityChanged(_:)), name: ReachabilityChangedNotification, object: reachability)
        
        do {
            try reachability!.startNotifier()
        } catch {
            
            print("cant access")
        }
    }
    
    class var sharedInstance1: SharedClass {
        struct Static {
            static var instance: SharedClass?
            static var token: Int = 0
        }
        
        if Static.instance == nil {
            Static.instance = SharedClass()
        }
        
        return Static.instance!
        
    }
    
    //Self delegate
    func reachabilityChanged(_ note: Notification) {
        
        guard let reachability = note.object as? Reachability else {
            return
        }
        
        if reachability.isReachable {
           
            self.isReachable = true

            if reachability.isReachableViaWiFi {
                print("Reachable via WiFi")
            } else {
                print("Reachable via Cellular")
            }
        } else {
              self.isReachable = false
        }
    }
}
