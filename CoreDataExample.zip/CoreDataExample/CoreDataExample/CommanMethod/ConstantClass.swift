//#04855E
//rgb(4,133,94)

import UIKit
class ConstantClass: NSObject {
    
    static var appDelegate = UIApplication.shared.delegate as? AppDelegate

  
     static var notifyId: String?
     static var notifyMessage: String?
     static var acceptedFollow: Bool = false
     static var sendFollow: Bool = false

    static var deviceToken: String?
    static var offlineView: Bool = false
   // static var jsonString: String?
    static var levelFlag: Bool = false
    static var defaults = UserDefaults.standard
    static var soundFlag: Bool = true
  

    struct Storyboard {
        static var login: UIStoryboard = UIStoryboard.init(name: "Login", bundle: nil)
        static var dashboard: UIStoryboard = UIStoryboard.init(name: "Dashboard", bundle: nil)
        static var setting: UIStoryboard = UIStoryboard.init(name: "Setting", bundle: nil)
        static var profile: UIStoryboard = UIStoryboard.init(name: "Profile", bundle: nil)
        static var createGame: UIStoryboard = UIStoryboard.init(name: "CreateGame", bundle: nil)
        static var downloadedGame: UIStoryboard = UIStoryboard.init(name: "DownloadedGame", bundle: nil)
        static var store: UIStoryboard = UIStoryboard.init(name: "Store", bundle: nil)
        static var playGame: UIStoryboard = UIStoryboard.init(name: "PlayGame", bundle: nil)
    }
    
    struct Device {
        
        static var kScreenBounds: CGRect = UIScreen.main.bounds
        
        static var isiPhoneFour: Bool   = 480 == UIScreen.main.bounds.size.height ? true:false //4 //4s
        static var isiPhoneFive: Bool   = 568 == UIScreen.main.bounds.size.height ? true:false //5 //5s
        static var isiPhoneSix: Bool   = 667 == UIScreen.main.bounds.size.height ? true:false //6 //6s
        static var isiPhoneSixPlus: Bool   = 736 == UIScreen.main.bounds.size.height ? true:false //6+ //6s+
        static var isiPad: Bool = 768 == UIScreen.main.bounds.size.height ? true:false
        static var isiPadRetina: Bool   = 1024 == UIScreen.main.bounds.size.height ? true:false  //Retina // Air
        static var isiPadPro: Bool   = 1366 == UIScreen.main.bounds.size.height ? true:false
        static var isiPhone: Bool   = 750 > UIScreen.main.bounds.size.height ? true : false
    }
    
    static func getDocumentsURL() -> URL {
        let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return documentsURL
    }
    static func fileInDocumentsDirectory(_ filename: String) -> String {
        let fileURL = getDocumentsURL().appendingPathComponent(filename)
        return fileURL.path
    }
    
    static func isNumberValue(_ numberString: String) -> Bool {
        if Int(numberString) != nil {
            return true
        }
        return false
    }
    
    static func convertStringToNumber(_ numberString: String) -> Int {
        if let number = Int(numberString) {
            return number
        }
        return 0
    }
    
    static func convertStringToFloat(_ numberString: String) -> Float {
        if let number = Float(numberString) {
            return number
        }
        return 0.0
    }
    
    static func convertStringToInt(_ numberString: String) -> Int {
        if let number = Int(numberString) {
            return number
        }
        return 0
    }
}
