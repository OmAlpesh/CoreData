//
//  Sales+Property.swift
//  CoreDataExample
//
//  Created by alpesh patel on 9/13/17.
//  Copyright © 2017 alpesh patel. All rights reserved.
//

import Foundation
import CoreData


extension Sales {
    
    @nonobjc public class func fetchRequest() -> NSFetchRequest<Sales> {
        return NSFetchRequest<Sales>(entityName: "Sales")
    }
    
    @NSManaged public var date: NSDate?
    @NSManaged public var item: String?
    @NSManaged public var quantity: String?
    @NSManaged public var salesId: String?
    @NSManaged public var salesRef: String?
    
}
