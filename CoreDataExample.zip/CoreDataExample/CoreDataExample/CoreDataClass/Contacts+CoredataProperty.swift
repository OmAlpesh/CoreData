//
//  Contacts+CoredataProperty.swift
//  CoreDataExample
//
//  Created by alpesh patel on 9/13/17.
//  Copyright © 2017 alpesh patel. All rights reserved.
//

import Foundation
import CoreData


extension Contacts {
    
    @nonobjc public class func fetchRequest() -> NSFetchRequest<Contacts> {
        return NSFetchRequest<Contacts>(entityName: "Contacts")
    }
    
    @NSManaged public var address: String?
    @NSManaged public var name: String?
    @NSManaged public var phone: String?
    @NSManaged public var relationship: Sales?
    
}
