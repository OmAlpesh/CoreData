//
//  Registration+Coredata.swift
//  CoreDataExample
//
//  Created by alpesh patel on 9/12/17.
//  Copyright © 2017 alpesh patel. All rights reserved.
//


import Foundation
import CoreData

@objc(Registration)
public class Registration: NSManagedObject {
    
}
